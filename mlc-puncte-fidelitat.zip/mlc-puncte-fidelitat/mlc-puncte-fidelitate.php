<?php
/*
Plugin Name: MLC Puncte Fidelitate Admin Live Search
Description: Căutare live user și adăugare puncte fidelitate cu verificare bon.
Version: 1.0
Author: ChatGPT
*/

add_action('admin_menu', function() {
    add_menu_page(
        'Adaugă Puncte',
        'Adaugă Puncte',
        'manage_options',
        'adauga-puncte',
        'mlc_admin_puncte_page'
    );
});

function mlc_admin_puncte_page() {
    if (!current_user_can('manage_options')) wp_die('Nu ai permisiuni!');

    if (isset($_POST['mlc_user_id'], $_POST['mlc_suma_huf'], $_POST['mlc_numar_bon'])) {
        $user_id = intval($_POST['mlc_user_id']);
        $suma = floatval($_POST['mlc_suma_huf']);
        $numar_bon = sanitize_text_field($_POST['mlc_numar_bon']);

        $user = get_user_by('ID', $user_id);
        if (!$user) {
            echo '<div style="color:red;">Userul nu a fost găsit.</div>';
        } else {
            $bonuri_folosite = get_user_meta($user_id, 'mlc_bonuri_folosite', true);
            if (!is_array($bonuri_folosite)) $bonuri_folosite = [];

            if (in_array($numar_bon, $bonuri_folosite)) {
                echo '<div style="color:red;">Acest număr de bon a fost deja folosit pentru acest user.</div>';
            } else {
                $puncte_de_adaugat = floor($suma / 100) * 4;
                $puncte_vechi = intval(get_user_meta($user_id, 'puncte_fidelitate', true));
                $puncte_noi = $puncte_vechi + $puncte_de_adaugat;

                update_user_meta($user_id, 'puncte_fidelitate', $puncte_noi);

                $bonuri_folosite[] = $numar_bon;
                update_user_meta($user_id, 'mlc_bonuri_folosite', $bonuri_folosite);

                echo '<div style="padding:10px; background:#d4edda; color:#155724;">';
                echo "Ai adăugat $puncte_de_adaugat puncte userului <strong>{$user->user_login}</strong> (ID: $user_id). Total puncte: $puncte_noi.";
                echo '</div>';
            }
        }
    }
    ?>

    <h1>Adaugă puncte fidelitate user</h1>
    <form method="post" id="mlc_form" autocomplete="off" style="position:relative; max-width:400px;">
        <label for="mlc_user_search">Caută user (username sau email):</label><br>
        <input type="text" id="mlc_user_search" placeholder="Scrie username sau email" required style="width:100%; padding:8px;">
        <input type="hidden" name="mlc_user_id" id="mlc_user_id" required>

        <ul id="mlc_user_list" style="border:1px solid #ccc; max-height:150px; overflow-y:auto; margin:0; padding:0; list-style:none; display:none; position:absolute; background:#fff; width:100%; z-index:9999;"></ul>

        <br><br>

        <label for="mlc_numar_bon">Număr bon / factură:</label><br>
        <input type="text" name="mlc_numar_bon" id="mlc_numar_bon" required style="width:100%; padding:8px;">

        <br><br>

        <label for="mlc_suma_huf">Suma (HUF):</label><br>
        <input type="number" name="mlc_suma_huf" id="mlc_suma_huf" min="0" step="1" required style="width:100%; padding:8px;">

        <br><br>

        <input type="submit" value="Adaugă puncte" style="padding:10px 20px;">
    </form>

    <style>
        #mlc_user_list li {
            padding: 8px;
            cursor: pointer;
        }
        #mlc_user_list li:hover {
            background-color: #eee;
        }
    </style>

    <script>
    jQuery(document).ready(function($){
        const $input = $('#mlc_user_search');
        const $list = $('#mlc_user_list');
        let timeout = null;

        $input.on('input', function(){
            clearTimeout(timeout);
            const term = $(this).val().trim();

            // Resetează ID dacă s-a modificat inputul
            $('#mlc_user_id').val('');

            if(term.length < 2){
                $list.hide();
                return;
            }

            timeout = setTimeout(function(){
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'mlc_user_search',
                        term: term
                    },
                    success: function(users){
                        if(users.length === 0){
                            $list.hide();
                            return;
                        }
                        $list.empty();
                        users.forEach(function(user){
                            $list.append(`<li data-id="${user.value}">${user.label}</li>`);
                        });
                        $list.show();
                    },
                    error: function(){
                        $list.hide();
                    }
                });
            }, 300);
        });

        $list.on('click', 'li', function(){
            const userId = $(this).data('id');
            const userLabel = $(this).text();

            $input.val(userLabel);
            $('#mlc_user_id').val(userId);
            $list.hide();
        });

        $(document).on('click', function(e){
            if(!$(e.target).closest('#mlc_user_search, #mlc_user_list').length){
                $list.hide();
            }
        });
    });
    </script>

    <?php
}

add_action('wp_ajax_mlc_user_search', function(){
    if (!current_user_can('manage_options')) {
        wp_send_json([]);
    }

    $term = sanitize_text_field($_POST['term'] ?? '');
    if (strlen($term) < 2) {
        wp_send_json([]);
    }

    $users = get_users([
        'search' => '*' . esc_attr($term) . '*',
        'search_columns' => ['user_login', 'user_email', 'display_name'],
        'number' => 10,
    ]);

    $results = [];
    foreach ($users as $user) {
        $label = $user->user_login . ' (' . $user->user_email . ')';
        $results[] = ['label' => $label, 'value' => $user->ID];
    }

    wp_send_json($results);
});
